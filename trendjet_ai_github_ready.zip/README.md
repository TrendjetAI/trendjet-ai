# TrendJet AI
This is the MVP starter for the TrendJet AI platform.